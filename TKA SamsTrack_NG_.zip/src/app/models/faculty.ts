export interface Faculty {
  id: number;
  name: string;
}
