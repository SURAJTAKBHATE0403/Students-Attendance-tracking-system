export interface Student {
  id: number;
  name: string;
  email: string;
  isSelected:boolean;
}
