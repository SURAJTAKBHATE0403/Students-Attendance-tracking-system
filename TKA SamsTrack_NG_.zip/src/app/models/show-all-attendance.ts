export interface ShowAllAttendance {
  id: number;
  username: number;
  date: string;
  time:string;
  numberOfStudents: number;
  studentNames: string[];
  subjectName:string


}
