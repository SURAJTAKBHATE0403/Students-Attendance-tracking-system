export interface AttendanceRecord {
  username: string;
  subjectId: number;
  date: string;
  time:string;
  numberOfStudents: number;
  studentIds: number[];


}
